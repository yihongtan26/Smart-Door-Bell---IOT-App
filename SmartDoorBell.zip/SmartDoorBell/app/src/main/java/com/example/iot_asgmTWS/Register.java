package com.example.iot_asgmTWS;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.util.LogPrinter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {
    EditText userName, userEmail, userPassword, userConfirmPassword;
    Button registerButton;
    TextView usrLoginBtn;
    FirebaseAuth fAuth;
    ProgressBar progressBar;
    FirebaseFirestore fStore;
    String userID;
    static boolean condition = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        userName = findViewById(R.id.userName);
        userEmail = findViewById(R.id.userEmailAddress);
        userPassword = findViewById(R.id.userPassword);
        userConfirmPassword = findViewById(R.id.userConfirmPassword);
        registerButton = findViewById(R.id.loginButton);
        usrLoginBtn = findViewById(R.id.createText);

        if (condition ==false) {
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setApplicationId("1:336828995317:android:cc795b380ab29f421f17bc")
                    .setApiKey("AIzaSyAw2JB_BQZTzB3f-oNiVTsSP0bpTlP7OGI")
                    .setDatabaseUrl("https://iot-assigment-593b9-default-rtdb.firebaseio.com")
                    .setProjectId("iot-assigment-593b9")
                    .build();
            FirebaseApp.initializeApp(this.getApplicationContext(), options, "second_database_name");

            condition = true;
        }


    }

    @Override
    protected  void onStart() {
        super.onStart();
        FirebaseApp secondApp = FirebaseApp.getInstance("second_database_name");

        fAuth = FirebaseAuth.getInstance(secondApp);
        fStore = FirebaseFirestore.getInstance(secondApp);

        progressBar = findViewById(R.id.progressBar);

        if(fAuth.getCurrentUser() != null && fAuth.getCurrentUser().isEmailVerified()) {
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
        }

        if(fAuth.getCurrentUser() != null) {
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
        }

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = userEmail.getText().toString().trim();
                String password = userPassword.getText().toString().trim();
                String confirmPassword = userConfirmPassword.getText().toString().trim();
                String name = userName.getText().toString().trim();

                if(TextUtils.isEmpty(name)) {
                    userName.setError("Name is Required.");
                    return;
                }

                if(TextUtils.isEmpty(email)) {
                    userEmail.setError("Email is Required.");
                    return;
                }

                if(TextUtils.isEmpty(password)) {
                    userPassword.setError("Email is Required.");
                    return;
                }

                if(password.length() <6) {
                    userPassword.setError("Password must more than 5 characters.");
                    return;
                }

                if(TextUtils.isEmpty(confirmPassword)) {
                    userConfirmPassword.setError("Confirm password is Required.");
                    return;
                }

                if(TextUtils.equals(password, confirmPassword)==false) {
                    userConfirmPassword.setError("Confirm password is not same with password.");
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);

                // register the user in firebase
                fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            //send verification email link--===============================================================================================

                            FirebaseUser userEmailVeri = fAuth.getCurrentUser();
                            userEmailVeri.sendEmailVerification().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(Register.this,"Verification Email has been sent",Toast.LENGTH_SHORT).show();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d("ExeptionMsg","onFailure: Email not sent " + e.getMessage());
                                }
                            });

                            Toast.makeText(Register.this, "User created.", Toast.LENGTH_SHORT).show();
                            userID = fAuth.getCurrentUser().getUid();
                            DocumentReference documentReference = fStore.collection("users").document(userID);

                            Map<String,Object> user = new HashMap<>();
                            user.put("name",userName.getText().toString());
                            user.put("email",userEmail.getText().toString());

                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d("TAG","onSuccess: user Profile is created for " + userID);
                                }
                            });
                            startActivity(new Intent(getApplicationContext(), Login.class));


                        }else {
                            Toast.makeText(Register.this, "Error !" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
            }

        });

        usrLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Login.class));

            }
        });
    }

}