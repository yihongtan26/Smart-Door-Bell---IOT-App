package com.example.iot_asgmTWS;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class imageModule extends AppCompatActivity {
    private StorageReference nstorageReference;
    private DatabaseReference rootDatabaseref;
    private DatabaseReference rootDatabaseref2;
    private StorageReference mStorage;
    private Button button1;
    private Button button2;
    private ImageView mImageView;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
    StorageReference storageReference = FirebaseStorage.getInstance().getReference();
    StorageReference mStorageReference = FirebaseStorage.getInstance().getReference();
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference listRef = storage.getReference().child("PI_12_CONTROL");

    int found = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);
        ArrayList<String> imageList = new ArrayList<>();

        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        mImageView = (ImageView) findViewById(R.id.imageView);

        rootDatabaseref = FirebaseDatabase.getInstance().getReference().child("PI_12_CONTROL");
        nstorageReference = FirebaseStorage.getInstance().getReference().child("Camera/camera.png");

        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference listRef = storage.getReference().child("PI_12_CONTROL");

        listRef.listAll().addOnSuccessListener(new OnSuccessListener<ListResult>() {
            @Override
            public void onSuccess(ListResult listResult) {
                imageList.clear();
                for(StorageReference fileRef : listResult.getItems()){
                    fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            imageList.add(uri.toString());
                            Log.d("item", uri.toString());

                        }
                    });

                }

            }
        });



        try {
            final File localFile = File.createTempFile("camera","png");
            nstorageReference.getFile(localFile)
                    .addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            Toast.makeText(imageModule.this, "Picture Retrieved", Toast.LENGTH_SHORT).show();
                            Bitmap bitmap = BitmapFactory.decodeFile(localFile.getAbsolutePath());
                            ((ImageView) findViewById(R.id.imageView)).setImageBitmap(bitmap);
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(imageModule.this,"Error Occurred",Toast.LENGTH_SHORT).show();
                }
            });
        }catch (IOException e) {
            e.printStackTrace();
        }


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                found = 0;

                HashMap hashMap = new HashMap();
                hashMap.put("camera","1");
                hashMap.put("lcdtxt","Picture Taken+++");
                rootDatabaseref.updateChildren(hashMap);

                try {
                    TimeUnit.SECONDS.sleep(5);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }


                listRef.listAll().addOnSuccessListener(new OnSuccessListener<ListResult>() {

                    @Override
                    public void onSuccess(ListResult listResult) {
                        imageList.clear();
                        for(StorageReference fileRef : listResult.getItems()){
                            fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    imageList.add(uri.toString());
                                    Log.d("item", uri.toString());

                                }
                            });

                        }

                    }
                });
                try {
                    TimeUnit.SECONDS.sleep(3);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                int lastPosition = imageList.size()-1;
                Picasso.get().load(imageList.get(lastPosition)).into(mImageView);

            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImage();
            }
        });

    }
    public void openImage(){
        Intent intent = new Intent(this, displayImage.class);
        startActivity(intent);
    }

}