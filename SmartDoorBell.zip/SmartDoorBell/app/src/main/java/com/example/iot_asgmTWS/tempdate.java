package com.example.iot_asgmTWS;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.NumberPicker;
import android.widget.RadioButton;
import android.widget.TextView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;

public class tempdate extends AppCompatActivity {

    static boolean condition = false;
    private TextView mDisplayDate;
    private TextView mDisplayHour;
    private TextView alarm;
    private  TextView ultra;
    private DatePickerDialog.OnDateSetListener onDateSetListener;
    static String chartDate;
    String sMonth;
    String sDay;
    static RadioButton btnTemp;
    static RadioButton btnUltra;
    static int chooseChart;
    static String hourChart,currentUserID;
    FirebaseAuth fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tempdate);
        mDisplayDate = (TextView) findViewById(R.id.tempdate);
        alarm = findViewById(R.id.alarm);
        ultra = findViewById(R.id.ultra);
        btnTemp = findViewById(R.id.btnTemp);
        btnUltra = findViewById(R.id.btnUltra);
        NumberPicker hourPick = findViewById(R.id.hourPicker);
        mDisplayHour = findViewById(R.id.hour);

        FirebaseApp secondApp = FirebaseApp.getInstance("second_database_name");


        fAuth = FirebaseAuth.getInstance(secondApp);
        currentUserID = fAuth.getCurrentUser().getUid();

        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(tempdate.this,android.R.style.Theme_Holo_Light_Dialog_MinWidth,onDateSetListener,year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;

                if(month == 1 || month == 2 || month == 3 || month == 4 || month == 5 ||month == 6 || month == 7 || month == 8 || month == 9){
                    sMonth = String.format("0" + month);
                }
                else
                    sMonth = String.valueOf(month);
                if(dayOfMonth == 1 || dayOfMonth == 2 || dayOfMonth == 3 || dayOfMonth == 4 || dayOfMonth == 5 ||dayOfMonth == 6 || dayOfMonth == 7 || dayOfMonth == 8 || dayOfMonth == 9){
                    sDay = String.format("0" + dayOfMonth);
                }
                else
                    sDay = String.valueOf(dayOfMonth);
                chartDate = String.format(year + sMonth + sDay);
                mDisplayDate.setText(chartDate);
                DatabaseReference reference = FirebaseDatabase.getInstance(secondApp).getReference().child("userID").child(currentUserID).child(chartDate);
                reference.child("alarm_Count").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String alarm1 = dataSnapshot.getValue(String.class);
                        alarm.setText("Alarm triggered:"+ alarm1);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
                reference.child("ultra_triggered_Count").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String ultra1 = dataSnapshot.getValue(String.class);
                        ultra.setText("Ultrasonic triggered:" + ultra1);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        };
        hourPick.setMaxValue(23);
        hourPick.setMinValue(00);
        hourPick.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                mDisplayHour.setText("Hour: " + newVal);
                if(newVal ==0 || newVal == 1 || newVal == 2 || newVal == 3 || newVal == 4 || newVal == 5 ||newVal == 6 || newVal == 7 || newVal == 8 || newVal == 9) {
                    hourChart = String.format("0"+newVal);
                }
                else
                    hourChart = String.valueOf(newVal);
            }
        });

    }

    public void proceed(View view) {
        Intent i = new Intent(this,chart.class);
        startActivity(i);
    }

    public void chkbtnAlarm(View view) {
        chooseChart = 1;
    }

    public void chkbtnUltra(View view) {
        chooseChart = 2;
    }
}
