package com.example.iot_asgmTWS;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    TextView wlcMsg, temp, lightStatus, ultraSonic, latestDataTime;
    Switch triggleAlarm;
    FirebaseDatabase fDataBase,myDataBase;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    Date currentDate;
    SimpleDateFormat df;
    ValueEventListener mainListener;

    String currentUserID;
    static int alarmCount = 1;
    static String previousDate;
    int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wlcMsg = findViewById(R.id.wlcUser);
        temp = findViewById(R.id.temp);
        lightStatus = findViewById(R.id.lightStatus);
        ultraSonic = findViewById(R.id.ultrasonic);
        latestDataTime = findViewById(R.id.latestDetect);
        triggleAlarm = findViewById(R.id.alarm);

    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseApp secondApp = FirebaseApp.getInstance("second_database_name");
        fAuth = FirebaseAuth.getInstance(secondApp);
        fStore = FirebaseFirestore.getInstance(secondApp);
        myDataBase = FirebaseDatabase.getInstance(secondApp);
        currentUserID = fAuth.getCurrentUser().getUid();
        fDataBase = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = fDataBase.getReference();
        DatabaseReference myDatabaseRef = myDataBase.getReference();
        DocumentReference userIDReference = fStore.collection("users").document(currentUserID);

        userIDReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                wlcMsg.setText("Welcome, " + value.getString("name"));
            }
        });

        triggleAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (triggleAlarm.isChecked()){
                    AlertDialog confirmAlarm = new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Trigger Alarm")
                            .setMessage("Are you confirm to trigger alarm ?")
                            .setPositiveButton("Ok", null)
                            .setNegativeButton("Cancel", null)
                            .show();

                    Button negativeButton =  confirmAlarm.getButton(AlertDialog.BUTTON_NEGATIVE);
                    negativeButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            triggleAlarm.setChecked(false);
                            confirmAlarm.dismiss();
                        }
                    });

                    Button positiveButton = confirmAlarm.getButton(AlertDialog.BUTTON_POSITIVE);
                    positiveButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            databaseReference.child("PI_12_CONTROL").child("buzzer").setValue("1");
                            currentDate = Calendar.getInstance().getTime();
                            df = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
                            String formattedDate = df.format(currentDate);
                            if (formattedDate.equals(previousDate) || previousDate==null){
                                previousDate = df.format(currentDate);
                            } else {
                                previousDate = df.format(currentDate);
                                alarmCount =1;
                            }
                            myDatabaseRef.child("userID").child(currentUserID).child(formattedDate).child("alarm_Count").setValue(Integer.toString(alarmCount));
                            alarmCount++;
                            confirmAlarm.dismiss();

                        }
                    });
                } else {
                    databaseReference.child("PI_12_CONTROL").child("buzzer").setValue("0");
                    Toast.makeText(MainActivity.this, "Alarm has been close." , Toast.LENGTH_SHORT).show();
                }
            }
        });

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //Log.e("Check data here", "countt" + String.valueOf(i++));
                currentDate = Calendar.getInstance().getTime();
                df = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
                String formattedDate = df.format(currentDate);

                String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                String currentH = currentTime.substring(0, 2);

                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                DataSnapshot controllerPath = dataSnapshot.child("PI_12_CONTROL");

                Query lastQuery = databaseReference.child("PI_12_" + formattedDate).child(currentH).orderByKey().limitToLast(1);

                lastQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        //Log.e("See data here", dataSnapshot.toString());
                        String random1 = "";
                        String temperature = "";
                        String ultrasonic = "";
                        int random1Ultra;
                        String minuteSec = dataSnapshot.getValue().toString().substring(1,5);

                        df = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                        String latestDateDate = df.format(currentDate);
                        latestDataTime.setText("Latest Detect Time: "+ latestDateDate +" "+currentH+":"+minuteSec.substring(0,2)+":"+minuteSec.substring(2,4));

                        for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                            try {
                                temperature = userSnapshot.child("tempe").getValue(String.class);
                            } catch (Exception e) {
                                temperature = "nan";

                            }
                            try {
                                ultrasonic = userSnapshot.child("ultra").getValue(String.class);
                            } catch (Exception e) {
                                ultrasonic = "nan";
                            }
                            try {
                                random1 = userSnapshot.child("rand1").getValue(String.class);
                                //Log.d("Random1", "value is : " + random1);
                            } catch (Exception e) {

                            }

                        }
                        random1Ultra = (int) (Integer.parseInt(ultrasonic) * Double.parseDouble(random1));

                        //Log.d("UltraSonic*Random1", "value is : " + random1Ultra);
                        myDatabaseRef.child("userID").child(currentUserID).child(formattedDate).child(currentH).child(minuteSec).child("temp").setValue(temperature);
                        temperature = "Temp :\n" + temperature + " C";
                        temp.setText(temperature.trim());

                        myDatabaseRef.child("userID").child(currentUserID).child(formattedDate).child(currentH).child(minuteSec).child("ultra").setValue(String.valueOf(random1Ultra));
                        ultrasonic = "Ultrasonic : " + random1Ultra + " cm";
                        ultraSonic.setText(ultrasonic.trim());
//                        if (random1Ultra<200){
//                            notification();
//                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        // Handle possible errors.
                    }
                });

                String ledStatus = controllerPath.child("ledlgt").getValue().toString();

                String msg;
                if (ledStatus.equals("1")) {
                    msg = "The Light is on.";
                } else {
                    msg = "The Light is off.";
                }
                lightStatus.setText(msg.trim());

            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("Tag", "Failed to read value.", error.toException());
            }
        });
    }

    public void logout(View view) {
        FirebaseApp secondApp = FirebaseApp.getInstance("second_database_name");
        FirebaseAuth.getInstance(secondApp).signOut();
        startActivity(new Intent(getApplicationContext(), Login.class));
        finish();
    }

    public void camera(View view) {
        startActivity(new Intent(getApplicationContext(), imageModule.class));
    }

    public void setting(View view) {
        startActivity(new Intent(getApplicationContext(), ManualSetting.class));
    }

    public void report(View view) {
        startActivity(new Intent(getApplicationContext(), tempdate.class));
    }

    public void lcd(View view) {
        startActivity(new Intent(getApplicationContext(), lcd.class));
    }

    public void smartLock(View view){
        startActivity(new Intent(getApplicationContext(), SmartLock.class));
    }

    private void notification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("n","n", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);

        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this,"n")
                .setContentText("Alert")
                .setSmallIcon(R.drawable.ic_noti)
                .setAutoCancel(true)
                .setContentText("Someone may in front of the door");

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(this);
        managerCompat.notify(999,builder.build());
    }


}
