package com.example.iot_asgmTWS;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import static com.example.iot_asgmTWS.tempdate.btnTemp;
import static com.example.iot_asgmTWS.tempdate.btnUltra;
import static com.example.iot_asgmTWS.tempdate.chartDate;
import static com.example.iot_asgmTWS.tempdate.chooseChart;
import static com.example.iot_asgmTWS.tempdate.hourChart;

public class chart extends AppCompatActivity {
    LineChart mplineChart;
    static boolean condition = false;
    DatabaseReference reference;
    FirebaseApp secondApp;
    int xsize = 0 ;
    int ysize = 0;
    double y;
    ArrayList<Integer> xValue = new ArrayList<>();
    ArrayList<Double> yValue = new ArrayList<>();
    static String currentUserID;
    FirebaseAuth fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);

        secondApp = FirebaseApp.getInstance("second_database_name");

        fAuth = FirebaseAuth.getInstance(secondApp);
        currentUserID = fAuth.getCurrentUser().getUid();

        if(chooseChart == 1) {
            reference = FirebaseDatabase.getInstance(secondApp).getReference().child("userID").child(currentUserID).child(chartDate);
            reference.child(hourChart).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                        String parent = childSnapshot.getKey();
                        if (parent.equalsIgnoreCase("alarm_Count")) {
                            break;
                        }
                        if (parent.equalsIgnoreCase("ultra_triggered_Count")) {
                            break;
                        }
                        int x = Integer.parseInt(parent);
                        xValue.add(xsize, x);
                        xsize++;
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

            reference.child(hourChart).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for (DataSnapshot dataSnapshot1 : snapshot.getChildren()) {
                        String temp = (String) dataSnapshot1.child("temp").getValue();
                        try {
                            if (temp.equalsIgnoreCase("nan")) {
                                y = 0.0;
                                yValue.add(ysize, y);
                                ysize++;
                            } else {
                                y = Double.parseDouble(temp);
                                yValue.add(ysize, y);
                                ysize++;
                            }
                        } catch (NullPointerException e) {
                            ysize--;
                            break;
                        }
                    }
                    mplineChart = (LineChart) findViewById(R.id.line_chart);
                    LineDataSet lineDataSet = new LineDataSet(dataValues(), "Temperature");
                    ArrayList<ILineDataSet> dataSets = new ArrayList<>();
                    dataSets.add(lineDataSet);

                    LineData data = new LineData(dataSets);
                    mplineChart.setData(data);
                    mplineChart.invalidate();
                    btnTemp.setChecked(false);
                    btnUltra.setChecked(false);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
        else{
            reference = FirebaseDatabase.getInstance(secondApp).getReference().child("userID").child(currentUserID).child(chartDate);
            reference.child(hourChart).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                        String parent = childSnapshot.getKey();
                        if (parent.equalsIgnoreCase("alarm_Count")) {
                            break;
                        }
                        if (parent.equalsIgnoreCase("ultra_triggered_Count")) {
                            break;
                        }
                        int x = Integer.parseInt(parent);
                        xValue.add(xsize, x);
                        xsize++;
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

            reference.child(hourChart).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for (DataSnapshot dataSnapshot1 : snapshot.getChildren()) {
                        String ultra = (String) dataSnapshot1.child("ultra").getValue();
                        try {
                            y = Double.parseDouble(ultra);
                            yValue.add(ysize, y);
                            ysize++;
                        } catch (NullPointerException e) {
                            ysize--;
                            break;
                        }
                    }
                    mplineChart = (LineChart) findViewById(R.id.line_chart);
                    LineDataSet lineDataSet = new LineDataSet(dataValues(), "Ultrasonic");
                    ArrayList<ILineDataSet> dataSets = new ArrayList<>();
                    dataSets.add(lineDataSet);

                    LineData data = new LineData(dataSets);
                    mplineChart.setData(data);
                    mplineChart.invalidate();
                    btnTemp.setChecked(false);
                    btnUltra.setChecked(false);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }

    }

    private ArrayList<Entry> dataValues() {
        ArrayList<Entry> dataVals = new ArrayList<Entry>();
        for (int j = 0; j < xsize; j++) {
            int newX = xValue.get(j);
            double newY = yValue.get(j);
            dataVals.add(new Entry(newX, (float) newY));
        }
        return dataVals;
    }

}