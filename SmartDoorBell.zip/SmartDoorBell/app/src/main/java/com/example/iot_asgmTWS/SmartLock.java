package com.example.iot_asgmTWS;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.TimePickerDialog;

import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

import com.google.api.Context;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;
import java.util.EventListener;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


public class SmartLock extends AppCompatActivity {
    String time1 ="00:00", time2="00:00",windowStatus;
    TextView timer1,timer2,windowCondition,setTime1,setTime2,smartLockStatus,lightCondition;
    int t1Hour,t1Minute,t2Hour,t2Minute,count;
    FirebaseDatabase fDataBase;
    private Handler handler = new Handler();
    private boolean started = true;
    DatabaseReference databaseReference;
    ValueEventListener windowListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smart_lock);
        fDataBase = FirebaseDatabase.getInstance();
        setTime1 = findViewById(R.id.setTime1);
        setTime2 = findViewById(R.id.setTime2);
        smartLockStatus = findViewById(R.id.smartLockStatus);
        windowCondition = findViewById(R.id.windowCondition);
        lightCondition = findViewById(R.id.lightCondition);
        databaseReference = fDataBase.getReference();

    }

    @Override
    protected void onStart() {
        super.onStart();
        timer1 = findViewById(R.id.timer1);
        timer2 = findViewById(R.id.timer2);

        timer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog = new TimePickerDialog(SmartLock.this,
                        android.R.style.Theme_Holo_Dialog_MinWidth,
                        new TimePickerDialog.OnTimeSetListener(){
                            @Override
                            public void onTimeSet(TimePicker view,int hourOfDay, int miniteOfDay) {
                                t1Hour = hourOfDay;
                                t1Minute = miniteOfDay;

                                time1  = (String.format("%02d:%02d", hourOfDay, miniteOfDay));
                                SimpleDateFormat f24H = new SimpleDateFormat(
                                        "HH:mm"
                                );
                                try {
                                    Date date = f24H.parse(time1);
                                    SimpleDateFormat f12H = new SimpleDateFormat(
                                            "hh:mm aa"
                                    );
                                    timer1.setText(f12H.format(date));

                                }catch (ParseException e) {
                                    e.printStackTrace();
                                }

                            }

                        },12,0,false
                );
                timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                timePickerDialog.updateTime(t1Hour,t1Minute);
                timePickerDialog.show();
            }
        });

        timer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TimePickerDialog timePickerDialog = new TimePickerDialog(SmartLock.this,
                        android.R.style.Theme_Holo_Dialog_MinWidth,
                        new TimePickerDialog.OnTimeSetListener(){
                            @Override
                            public void onTimeSet(TimePicker view,int hourOfDay, int miniteOfDay) {
                                t2Hour = hourOfDay;
                                t2Minute = miniteOfDay;

                                time2  = (String.format("%02d:%02d", hourOfDay, miniteOfDay));
                                SimpleDateFormat f24H = new SimpleDateFormat(
                                        "HH:mm"
                                );
                                try {
                                    Date date = f24H.parse(time2);
                                    SimpleDateFormat f12H = new SimpleDateFormat(
                                            "hh:mm aa"
                                    );
                                    timer2.setText(f12H.format(date));

                                }catch (ParseException e) {
                                    e.printStackTrace();
                                }

                            }

                        },12,0,false
                );
                timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                timePickerDialog.updateTime(t2Hour,t2Minute);
                timePickerDialog.show();
            }
        });


    }

    public void setTimerTime(View view) {

        setTime1.setText(time1.trim());
        setTime2.setText(time2.trim());
        count=0;
        runnable.run();
    }

    public void start() {
        started = true;
        handler.postDelayed(runnable, 2000);
    }

    private final Runnable runnable = new Runnable() {

        @Override
        public void run() {
            if (count == 0) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm");
                Date endTime = null;
                Date startTime = null;
                Date CurrentTime = null;
                try {
                    CurrentTime = dateFormat.parse(dateFormat.format(new Date()));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                try {
                    endTime = dateFormat.parse(time2);
                    startTime = dateFormat.parse(time1);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                if (CurrentTime.before(endTime) && CurrentTime.after(startTime)) {
                    databaseReference.child("PI_12_CONTROL").child("ledlgt").setValue("1");
                    lightCondition.setText("on");
                    count = 0;

                    if (started ) {
                        smartLockStatus.setText("Status on");
                        windowListener = new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                windowStatus = dataSnapshot.getValue().toString();
                                Log.e("here", windowStatus);
                                String msg;
                                if (windowStatus.equals("1") && count == 0) {
                                    count = 1;
                                    started = false;
                                    msg = "open";
                                    windowCondition.setText(msg);
                                    databaseReference.child("PI_12_CONTROL").child("buzzer").setValue("1");
                                    notification();

                                    AlertDialog confirmAlarm = new AlertDialog.Builder(SmartLock.this)
                                            .setTitle("Trigger Alarm")
                                            .setMessage("Click ok to close alarm")
                                            .setPositiveButton("Ok", null)
                                            .show();

                                    Button positiveButton = confirmAlarm.getButton(AlertDialog.BUTTON_POSITIVE);
                                    positiveButton.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            confirmAlarm.dismiss();
                                            databaseReference.child("PI_12_CONTROL").child("relay2").addValueEventListener(windowListener);
                                            databaseReference.child("PI_12_CONTROL").child("buzzer").setValue("0");
                                            databaseReference.child("PI_12_CONTROL").child("relay2").setValue("0");
                                            windowStatus = "0";
                                            smartLockStatus.setText("Status off");
                                            //Log.e("here2", windowStatus);

                                            started = true;
                                            return;

                                        }
                                    });
                                } else {
                                    msg = "closed";
                                }
                                windowCondition.setText(msg);
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                // Handle possible errors.
                            }
                        };
                        databaseReference.child("PI_12_CONTROL").child("relay2").addValueEventListener(windowListener);

                    }
                } else {
                    lightCondition.setText("off");
                    databaseReference.child("PI_12_CONTROL").child("ledlgt").setValue("0");
                    smartLockStatus.setText("Status off");
                }
                Log.e("CHeckCHek", String.valueOf(started));
                if (started == true)
                    start();
            }
        }
    };
    private void notification() {
        if (count == 0) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel("window", "window", NotificationManager.IMPORTANCE_DEFAULT);
                NotificationManager manager = getSystemService(NotificationManager.class);
                manager.createNotificationChannel(channel);

            }

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "window")
                    .setContentText("Alert")
                    .setSmallIcon(R.drawable.ic_noti)
                    .setAutoCancel(true)
                    .setContentText("The window has been open");

            NotificationManagerCompat managerCompat = NotificationManagerCompat.from(this);
            managerCompat.notify(999, builder.build());

        }
    }


}