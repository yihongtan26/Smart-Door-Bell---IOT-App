package com.example.iot_asgmTWS;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class ManualSetting extends AppCompatActivity {

    TextInputEditText camMetre, ledTime1, ledTime2, buzzTime1, buzzTime2;
    int ledT1, ledT2, buzzT1, buzzT2, random1Ultra, random2Ultra, ultraTriggerCount = 0, alarmCount = 0;
    String cameraMetre, ledStart, ledEnd, buzzStart, buzzEnd, currentUserID;
    ArrayList<String> imageList = new ArrayList<>();
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    Switch switchBtn;
    Button saveBtn, okBtn;
    Boolean condition = false;
    ImageView camImage;

    FirebaseDatabase rootNode, myDataBase;
    DatabaseReference buzzer, camera, ledlgt, databaseReference, myDatabaseRef;
    FirebaseAuth fAuth;
    FirebaseStorage storage;
    StorageReference listRef;

    ValueEventListener databaseListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting_main);

//        if (!condition) {
//            FirebaseOptions options = new FirebaseOptions.Builder()
//                    .setApplicationId("1:336828995317:android:cc795b380ab29f421f17bc")
//                    .setApiKey("AIzaSyAw2JB_BQZTzB3f-oNiVTsSP0bpTlP7OGI")
//                    .setDatabaseUrl("https://iot-assigment-593b9-default-rtdb.firebaseio.com")
//                    .setProjectId("iot-assigment-593b9")
//                    .build();
//            FirebaseApp.initializeApp(this.getApplicationContext(), options, "second_database_name");
//
//            condition = true;
//        }

        camMetre = findViewById(R.id.camMetreTxt);
        ledTime1 = findViewById(R.id.ledTimeTxt1);
        ledTime2 = findViewById(R.id.ledTimeTxt2);
        buzzTime1 = findViewById(R.id.buzzTimeTxt1);
        buzzTime2 = findViewById(R.id.buzzTimeTxt2);
        switchBtn = findViewById(R.id.switchOnOff);
        saveBtn = findViewById(R.id.saveBtn);

        switchBtn.setChecked(true);
        camMetre.setEnabled(false);
        camMetre.setText("10");
        ledTime1.setEnabled(false);
        ledTime1.setText("00:00");
        ledTime2.setEnabled(false);
        ledTime2.setText("06:00");
        buzzTime1.setEnabled(false);
        buzzTime1.setText("00:00");
        buzzTime2.setEnabled(false);
        buzzTime2.setText("06:00");

        cameraMetre = String.valueOf(camMetre.getText());
        ledStart = String.valueOf(ledTime1.getText()).substring(0,2);
        ledEnd = String.valueOf(ledTime2.getText()).substring(0,2);
        buzzStart = String.valueOf(buzzTime1.getText()).substring(0,2);
        buzzEnd = String.valueOf(buzzTime2.getText()).substring(0,2);
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseApp secondApp = FirebaseApp.getInstance("second_database_name");
        fAuth = FirebaseAuth.getInstance(secondApp);
        currentUserID = fAuth.getCurrentUser().getUid();

        storage = FirebaseStorage.getInstance();
        listRef = storage.getReference().child("PI_12_CONTROL");

        listRef.listAll().addOnSuccessListener(new OnSuccessListener<ListResult>() {

            @Override
            public void onSuccess(ListResult listResult) {
                imageList.clear();
                for(StorageReference fileRef : listResult.getItems()){
                    fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            imageList.add(uri.toString());
                            Log.d("item", uri.toString());
                        }
                    });

                }

            }
        });

        switchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (switchBtn.isChecked()) {
                    camMetre.setEnabled(false);
                    camMetre.setText("10");
                    ledTime1.setEnabled(false);
                    ledTime1.setText("00:00");
                    ledTime2.setEnabled(false);
                    ledTime2.setText("06:00");
                    buzzTime1.setEnabled(false);
                    buzzTime1.setText("00:00");
                    buzzTime2.setEnabled(false);
                    buzzTime2.setText("06:00");

                } else {
                    camMetre.setEnabled(true);
                    ledTime1.setEnabled(true);
                    ledTime2.setEnabled(true);
                    buzzTime1.setEnabled(true);
                    buzzTime2.setEnabled(true);

                    ledTime1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            TimePickerDialog timePickerDialog = new TimePickerDialog(
                                    ManualSetting.this,
                                    android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                                    (view, hourOfDay, minute) -> {
                                        ledT1 = hourOfDay;
                                        String time = ledT1 + ": 00";
                                        @SuppressLint("SimpleDateFormat") SimpleDateFormat f24Hours = new SimpleDateFormat(
                                                "HH:mm"
                                        );
                                        try {
                                            Date date = f24Hours.parse(time);
                                            @SuppressLint("SimpleDateFormat") SimpleDateFormat display = new SimpleDateFormat(
                                                    "HH:mm"
                                            );
                                            ledTime1.setText(display.format(date));
                                        } catch (ParseException e) {
                                            e.printStackTrace();
                                        }
                                    }, 12, 0, false
                            );
                            timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            timePickerDialog.updateTime(ledT1, 0);
                            timePickerDialog.show();
                        }
                    });

                    ledTime2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            TimePickerDialog timePickerDialog = new TimePickerDialog(
                                    ManualSetting.this,
                                    android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                                    (view, hourOfDay, minute) -> {
                                        ledT2 = hourOfDay;
                                        String time = ledT2 + ": 00";
                                        @SuppressLint("SimpleDateFormat") SimpleDateFormat f24Hours = new SimpleDateFormat(
                                                "HH:mm"
                                        );
                                        try {
                                            Date date = f24Hours.parse(time);
                                            @SuppressLint("SimpleDateFormat") SimpleDateFormat display = new SimpleDateFormat(
                                                    "HH:mm"
                                            );
                                            ledTime2.setText(display.format(date));
                                        } catch (ParseException e) {
                                            e.printStackTrace();
                                        }
                                    }, 12, 0, false
                            );
                            timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            timePickerDialog.updateTime(ledT2, 0);
                            timePickerDialog.show();
                        }
                    });

                    buzzTime1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            TimePickerDialog timePickerDialog = new TimePickerDialog(
                                    ManualSetting.this,
                                    android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                                    (view, hourOfDay, minute) -> {
                                        buzzT1 = hourOfDay;
                                        String time = buzzT1 + ": 00";
                                        @SuppressLint("SimpleDateFormat") SimpleDateFormat f24Hours = new SimpleDateFormat(
                                                "HH:mm"
                                        );
                                        try {
                                            Date date = f24Hours.parse(time);
                                            @SuppressLint("SimpleDateFormat") SimpleDateFormat display = new SimpleDateFormat(
                                                    "HH:mm"
                                            );
                                            buzzTime1.setText(display.format(date));
                                        } catch (ParseException e) {
                                            e.printStackTrace();
                                        }
                                    }, 12, 0, false
                            );
                            timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            timePickerDialog.updateTime(buzzT1, 0);
                            timePickerDialog.show();
                        }
                    });

                    buzzTime2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            TimePickerDialog timePickerDialog = new TimePickerDialog(
                                    ManualSetting.this,
                                    android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                                    (view, hourOfDay, minute) -> {
                                        buzzT2 = hourOfDay;
                                        String time = buzzT2 + ": 00";
                                        @SuppressLint("SimpleDateFormat") SimpleDateFormat f24Hours = new SimpleDateFormat(
                                                "HH:mm"
                                        );
                                        try {
                                            Date date = f24Hours.parse(time);
                                            @SuppressLint("SimpleDateFormat") SimpleDateFormat display = new SimpleDateFormat(
                                                    "HH:mm"
                                            );
                                            buzzTime2.setText(display.format(date));
                                        } catch (ParseException e) {
                                            e.printStackTrace();
                                        }
                                    }, 12, 0, false
                            );
                            timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            timePickerDialog.updateTime(buzzT2, 0);
                            timePickerDialog.show();
                        }
                    });

                }
            }
        });

        saveBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                cameraMetre = String.valueOf(camMetre.getText());
                ledStart = String.valueOf(ledTime1.getText()).substring(0,2);
                ledEnd = String.valueOf(ledTime2.getText()).substring(0,2);
                buzzStart = String.valueOf(buzzTime1.getText()).substring(0,2);
                buzzEnd = String.valueOf(buzzTime2.getText()).substring(0,2);
                Toast.makeText(ManualSetting.this, "Setting Saved.", Toast.LENGTH_LONG).show();
            }
        });

        rootNode = FirebaseDatabase.getInstance();
        databaseReference = rootNode.getReference();

        databaseListener = new ValueEventListener() {
            int i=0;
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                Date currentDate = Calendar.getInstance().getTime();
                SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
                df.setTimeZone(TimeZone.getTimeZone("GMT+8"));
                String formattedDate = df.format(currentDate);

                SimpleDateFormat hours = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
                hours.setTimeZone(TimeZone.getTimeZone("GMT+8"));
                String currentH = hours.format(currentDate).substring(0, 2);


                Query lastQuery = databaseReference.child("PI_12_" + formattedDate).child(currentH).orderByKey().limitToLast(1);
                lastQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Log.e("See data here", dataSnapshot.toString());
                        String ultrasonic = "";
                        String random1 = "";
                        String random2 = "";
                        for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                            try {
                                random1 = userSnapshot.child("rand1").getValue(String.class);
                                Log.d("Random1", "value is : " + random1);
                            } catch (Exception e) {
                            }
                            try {
                                random2 = userSnapshot.child("rand2").getValue(String.class);
                                Log.d("Random2", "value is : " + random2);
                            } catch (Exception e) {
                            }
                            try {
                                ultrasonic = userSnapshot.child("ultra").getValue(String.class);
                                Log.d("UltraSonic", "value is : " + ultrasonic);
                            } catch (Exception e) {
                            }
                        }
                        try {
                            random1Ultra = (int) (Integer.parseInt(ultrasonic) * Double.parseDouble(random1));
                            Log.d("UltraSonic*Random1", "value is : " + random1Ultra);
                        } catch(NumberFormatException nfe) {
                            System.out.println("Could not parse " + nfe);
                        }
                        try {
                            random2Ultra = (int) (Integer.parseInt(ultrasonic) * Double.parseDouble(random2));
                            Log.d("UltraSonic*Random2", "value is : " + random2Ultra);
                        } catch(NumberFormatException nfe) {
                            System.out.println("Could not parse " + nfe);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

                buzzer = rootNode.getReference("PI_12_CONTROL").child("buzzer");
                buzzer.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String value = dataSnapshot.getValue(String.class);
                        Log.d("Buzzer", "value is : " + value);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // Failed to read value
                        Log.w("Buzzer", "Failed to read value.", error.toException());
                    }
                });

                camera = rootNode.getReference("PI_12_CONTROL").child("camera");
                camera.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String value = dataSnapshot.getValue(String.class);
                        Log.d("Camera", "value is : " + value);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // Failed to read value
                        Log.w("Camera", "Failed to read value.", error.toException());
                    }
                });

                ledlgt = rootNode.getReference("PI_12_CONTROL").child("ledlgt");
                ledlgt.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String value = dataSnapshot.getValue(String.class);
                        Log.d("ledlgt", "value is : " + value);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        // Failed to read value
                        Log.w("ledlgt", "Failed to read value.", error.toException());
                    }
                });

                Date startLed = null, endLed = null, startBuzz = null, endBuzz = null;
                @SuppressLint("SimpleDateFormat") SimpleDateFormat HHformat = new SimpleDateFormat("HH:mm");
                HHformat.setTimeZone(TimeZone.getTimeZone("GMT+8"));
                Date currentHour = new Date(System.currentTimeMillis());
                String currentHourS = HHformat.format(currentHour);

                try{
                    startLed = HHformat.parse(ledStart + ":00");
                    endLed = HHformat.parse(ledEnd + ":00");
                    startBuzz = HHformat.parse(buzzStart + ":00");
                    endBuzz = HHformat.parse(buzzEnd + ":00");
                    currentHour = HHformat.parse(currentHourS + ":00");
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                if(currentHour.after(startLed) && currentHour.before(endLed)){
                    ledlgt.setValue("1");
                }else{
                    ledlgt.setValue("0");
                }

                myDataBase = FirebaseDatabase.getInstance(secondApp);
                myDatabaseRef = myDataBase.getReference();
                currentDate = Calendar.getInstance().getTime();

                if(currentHour.after(startBuzz) && currentHour.before(endBuzz)){
                    if(random2Ultra <= (Integer.parseInt(cameraMetre)*100)) {
                        buzzer.setValue("1");
                        try {
                            myDatabaseRef.child("userID").child(currentUserID).child(formattedDate).child("alarm_Count").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    alarmCount = Integer.parseInt(snapshot.getValue(String.class));
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                }
                            });
                            alarmCount++;
                            myDatabaseRef.child("userID").child(currentUserID).child(formattedDate).child("alarm_Count").setValue(Integer.toString(alarmCount));
                        }catch (Exception ignored){
                        }
                        if(alarmCount == 0){
                            alarmCount = 1;
                            myDatabaseRef.child("userID").child(currentUserID).child(formattedDate).child("alarm_Count").setValue(Integer.toString(alarmCount));
                        }
                    }
                    else
                        buzzer.setValue("0");
                }

                if(random2Ultra <= (Integer.parseInt(cameraMetre)*100)){
                    camera.setValue("1");
                    notification();
                    try {
                        myDatabaseRef.child("userID").child(currentUserID).child(formattedDate).child("ultra_triggered_Count").addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                ultraTriggerCount = Integer.parseInt(snapshot.getValue(String.class));
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                        ultraTriggerCount++;
                        myDatabaseRef.child("userID").child(currentUserID).child(formattedDate).child("ultra_triggered_Count").setValue(Integer.toString(ultraTriggerCount));
                    }catch (Exception ignored){
                    }
                    if(ultraTriggerCount == 0){
                        ultraTriggerCount = 1;
                        myDatabaseRef.child("userID").child(currentUserID).child(formattedDate).child("ultra_triggered_Count").setValue(Integer.toString(ultraTriggerCount));
                    }
                    showAlertDialog();
                }else
                    camera.setValue("0");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        };

        databaseReference.addValueEventListener(databaseListener);

    }

    @Override
    protected void onStop() {
        super.onStop();
        if(databaseListener != null)
            databaseReference.removeEventListener(databaseListener);
    }

    private void notification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("n","n", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this,"n")
                .setContentText("Alert")
                .setSmallIcon(R.drawable.ic_noti)
                .setAutoCancel(true)
                .setContentText("Someone may in front of the door");

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(this);
        managerCompat.notify(999,builder.build());
    }

    public void showAlertDialog(){
        databaseReference.removeEventListener(databaseListener);
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Alert");
        alert.setMessage("Someone may in front of the door.\nDo you want to check it through camera?");
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                createViewImageDialog();
            }
        });
        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                databaseReference.addValueEventListener(databaseListener);
            }
        });
        alert.create().show();
    }

    public void createViewImageDialog(){

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        final View imagePopupView = getLayoutInflater().inflate(R.layout.popup_cam_image,null);
        camImage = imagePopupView.findViewById(R.id.camImage);
        okBtn = imagePopupView.findViewById(R.id.okBtn);

        int lastPosition = imageList.size()-1;
        Picasso.get().load(imageList.get(lastPosition)).into(camImage);

        dialogBuilder.setView(imagePopupView);

        final AlertDialog show = dialogBuilder.show();

        okBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                databaseReference.addValueEventListener(databaseListener);
                show.cancel();
            }
        });
    }

}